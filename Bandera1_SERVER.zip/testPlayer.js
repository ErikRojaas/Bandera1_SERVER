const WebSocket = require('ws')

const socket = new WebSocket('ws://localhost:8080?type=mobile');

socket.addEventListener('open', (event) => {
    console.log('Connected to WebSocket server');
});
socket.addEventListener('message', (event) => {
});
socket.addEventListener('error', (event) => {
    console.error('WebSocket error:', event);
});
socket.addEventListener('close', (event) => {
    console.log('Disconnected from WebSocket server');
});

function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function sendDirections() {
    await wait(1000);
    while (true) {
        console.log("walking square");
        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: 0, dy: 100 } } }));
        await wait(1000);

        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: 0, dy: 0 } } }));
        await wait(1000);

        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: 100, dy: 0 } } }));
        await wait(1000);

        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: 0, dy: 0 } } }));
        await wait(1000);0

        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: 0, dy: -100 } } }));
        await wait(1000);

        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: 0, dy: 0 } } }));
        await wait(1000);

        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: -100, dy: 0 } } }));
        await wait(1000);

        socket.send(JSON.stringify({ type: "direction", data: { direction: { dx: 0, dy: 0 } } }));
        await wait(1000);
    }
}

sendDirections();